let valori = [3, 8, 12, 4, 5, 2, 7, 22, 17, 2, 1, 43];

    for(let i = 0; i < valori.length; i ++){
        if(valori[i] > 10){
            console.log(valori[i] + " *. ");
        }else{
            console.log(valori[i]);
        }
    }

