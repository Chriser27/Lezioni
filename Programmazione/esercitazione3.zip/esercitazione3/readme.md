# Esercitazione con valutazione

1. Costruire una struttura per un progetto html con le cartelle corrette
2. Inserire un titolo principale "Esercitazione Nome Cognome"
3. Collegare correttamente un file js ad un file html
4. Costruire 4 variabili che descrivono te stesso:
    - nome
    - cognome
    - età
    - corso frequentato
5. Stampare in console una descrizione completa di te stesso usando le variabili instanziate.
6. Inserire un controllo dell'età. Se maggiore di 18 anni stampare in console "SEI MAGGIORENNE, LA LEGGE TI ASPETTA", se minore di 18 anni stampare in console "SEI MINORENNE MA MANCA POCO".