let nome = "Christian"
let cognome = "Spitaleri"
let eta = 17;
let corsofrequentato = "Operatore Informatico"

console.log("Ciao! Sono " + nome + " " + cognome + ", ho " + eta + " anni e frequento il corso di " + corsofrequentato + ".");

if(eta >= 18){
    console.log("Sei maggiorenne, la legge ti aspetta.");
}else{
    console.log("Sei minorenne, manca poco.");
}